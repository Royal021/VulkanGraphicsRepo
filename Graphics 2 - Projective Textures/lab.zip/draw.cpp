#include "vkhelpers.h"
#include "utils.h"
#include "Globals.h"
#include "Uniforms.h"
#include "importantConstants.h"
#include "utils.h"
#include "math2801.h"

void draw(Globals& globs)
{
    //begin rendering the frame
    VkCommandBuffer cmd = utils::beginFrame(globs.ctx);

    //set skybox environmap
    globs.descriptorSet->setSlot(
        ENVMAP_TEXTURE_SLOT,
        globs.Environmap->view()
    );

    globs.descriptorSet->setSlot(
        PROJECTED_TEXTURE_SLOT,
        globs.projectedTexture->view()
    );

    //set uniforms
    globs.camera.setUniforms(globs.uniforms);
    globs.allLights->setUniforms(globs.uniforms);

    globs.uniforms->set("projTexPlane", math2801::vec4(1, 0, 0, 14.60563f));
    globs.uniforms->set("projTexLightDir", math2801::vec3(-0.539697f, 0.796550f, 0.272461f));
    globs.uniforms->set("projTexEastVector", math2801::vec3(0, 0, -1));
    globs.uniforms->set("projTexSouthVector", math2801::vec3(0, -1, 0));
    globs.uniforms->set("projTexCorner", math2801::vec3(-14.60563f, 15.7229f, 2.87881f));
    globs.uniforms->set("projTexSize", math2801::vec2(5.662f, 5.769f));

    globs.uniforms->update(cmd,globs.descriptorSet,UNIFORM_BUFFER_SLOT);

    

    //bind descriptor set
    globs.descriptorSet->bind(cmd);

    //begin rendering to the screen
    globs.framebuffer->beginRenderPassClearContents(cmd, 0.2f, 0.4f, 0.8f, 1.0f);

    //activate the pipeline
    globs.pipeline->use(cmd);

    //set source for vertex data
    globs.vertexManager->bindBuffers(cmd);

    //draw the meshes
    for(auto& m : globs.allMeshes){
        m->draw(cmd,globs.descriptorSet,globs.pushConstants);
    }

    //draw the sky
    globs.skymappipeline->use(cmd);
    globs.descriptorSet->setSlot(
        ENVMAP_TEXTURE_SLOT, globs.skyBoxImage->view());
    globs.descriptorSet->bind(cmd);
    globs.skyboxMesh->draw(cmd,
        globs.descriptorSet, globs.pushConstants);

    //done rendering
    globs.framebuffer->endRenderPass(cmd);

    //submit frame to GPU
    utils::endFrame(globs.ctx);
}
